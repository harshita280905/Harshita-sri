package com.example.leavemanagement;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.example.leavemanagement.dao.LeaveDAO;
import com.example.leavemanagement.model.Leave;

public class LeaveDAOTest {

    @Test
    public void testApplyLeave() {

        Leave leave = new Leave();
        leave.setUserEmail("junituser@gmail.com");
        leave.setFromDate("2025-01-10");
        leave.setToDate("2025-01-12");
        leave.setLeaveType("CASUAL");
        leave.setReason("JUnit testing");
        leave.setStatus("PENDING");

        boolean result = LeaveDAO.applyLeave(leave);

        assertTrue(result, "Leave should be applied successfully");
    }
    

}

