package com.example.leavemanagement;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.example.leavemanagement.dao.UserDAO;
import com.example.leavemanagement.model.User;

public class UserDAOTest {

    @Test
    public void testRegisterUser() {

        User user = new User();
        user.setName("JUnit User");
        user.setEmail("junituser@gmail.com");
        user.setPassword("1234");
        user.setRole("EMPLOYEE");

        boolean result = UserDAO.register(user);

        assertTrue(result, "User registration should be successful");
    }
}
