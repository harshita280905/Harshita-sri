package com.example.leavemanagement.controller;


import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;

import com.example.leavemanagement.dao.LeaveDAO;
import com.example.leavemanagement.model.Leave;
import com.example.leavemanagement.model.User;

@RestController
@RequestMapping("/leave")
@CrossOrigin
public class LeaveController {
	

    // ================= EMPLOYEE =================

    // APPLY LEAVE
	@PostMapping(
	        value = "/apply"
	        
	    )
	    public String applyLeave(
	            @RequestParam String fromDate,
	            @RequestParam String toDate,
	            @RequestParam String leaveType,
	            @RequestParam String reason,
	            HttpSession session) {

	        User user = (User) session.getAttribute("user");

	        // 🔍 DEBUG (ADD THIS)
	        System.out.println("USER IN SESSION = " + user);

	        if (user == null) {
	            return "NOT_LOGGED_IN";
	        }

	        Leave leave = new Leave();
	        leave.setUserEmail(user.getEmail());   // ✅ REQUIRED
	        leave.setFromDate(fromDate);
	        leave.setToDate(toDate);
	        leave.setLeaveType(leaveType);
	        leave.setReason(reason);
	        leave.setStatus("PENDING");

	        boolean inserted = LeaveDAO.applyLeave(leave);

	        System.out.println("LEAVE INSERT RESULT = " + inserted);

	        return inserted ? "SUCCESS" : "FAILED";
	    }
	

	    @GetMapping("/my")
	    public Object myLeaves(HttpSession session) {

	        User user = (User) session.getAttribute("user");
	        if (user == null) return "NOT_LOGGED_IN";

	        return LeaveDAO.getLeavesByEmail(user.getEmail());
	    }
	    


	    @GetMapping("/all")
	    public Object allLeaves(HttpSession session) {

	        User user = (User) session.getAttribute("user");
	        if (user == null) return "NOT_LOGGED_IN";

	        if (!"MANAGER".equalsIgnoreCase(user.getRole()))
	            return "UNAUTHORIZED";

	        return LeaveDAO.getAllLeaves();
	    }

	    @PutMapping("/approve/{id}")
	    public String approve(@PathVariable int id) {
	        LeaveDAO.updateStatus(id, "ACCEPTED");
	        return "SUCCESS";
	    }

	    @PutMapping("/reject/{id}")
	    public String reject(@PathVariable int id) {
	        LeaveDAO.updateStatus(id, "REJECTED");
	        return "SUCCESS";
	    }
	}
