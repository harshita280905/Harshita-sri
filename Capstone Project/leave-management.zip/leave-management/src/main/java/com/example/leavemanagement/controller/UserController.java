package com.example.leavemanagement.controller;

import com.example.leavemanagement.dao.UserDAO;
import com.example.leavemanagement.model.User;

import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "*")
public class UserController {

    // ===============================
    // 1. GET ALL USERS
    // ===============================
    @GetMapping("/all")
    public List<User> getAllUsers() {
        return UserDAO.getAllUsers();
    }

    // ===============================
    // 2. UPDATE USER
    // ===============================
    @PostMapping(value = "/update", consumes = "application/json")
    public String updateUser(@RequestBody User user) {

        boolean updated = UserDAO.updateUser(user);
        return updated ? "UPDATED" : "FAILED";
    }

    // ===============================
    // 3. DELETE USER
    // ===============================
    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable int id) {

        boolean deleted = UserDAO.deleteUser(id);
        return deleted ? "DELETED" : "FAILED";
    }

    // ===============================
    // 4. CHANGE PASSWORD
    // ===============================
    @PostMapping("/change-password")
    public String changePassword(@RequestBody Map<String, String> data,
                                 HttpSession session) {

        User loggedUser = (User) session.getAttribute("user");

        if (loggedUser == null) {
            return "LOGIN_REQUIRED";
        }

        String currentPassword = data.get("currentPassword");
        String newPassword = data.get("newPassword");

        boolean updated = UserDAO.changePassword(
                loggedUser.getEmail(),
                currentPassword,
                newPassword
        );

        return updated ? "SUCCESS" : "INVALID_PASSWORD";
    }
}
