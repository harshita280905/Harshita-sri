package com.example.leavemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.example.leavemanagement.model.User;
import com.example.leavemanagement.util.DBConnection;

public class UserDAO {

    // ================= REGISTER =================
	public static boolean register(User user) {
	    Connection con = null;
	    PreparedStatement ps = null;

	    try {
	        con = DBConnection.getConnection();

	        System.out.println("====== REGISTER DAO HIT ======");
	        System.out.println("Name: " + user.getName());
	        System.out.println("Email: " + user.getEmail());
	        System.out.println("Password: " + user.getPassword());
	        System.out.println("Role: " + user.getRole());

	        if (con == null) {
	            System.out.println("❌ CONNECTION NULL");
	            return false;
	        }

	        ps = con.prepareStatement(
	            "INSERT INTO users(name,email,password,role) VALUES (?,?,?,?)"
	        );

	        ps.setString(1, user.getName());
	        ps.setString(2, user.getEmail());
	        ps.setString(3, user.getPassword());
	        ps.setString(4, user.getRole());

	        int rows = ps.executeUpdate();
	        System.out.println("ROWS INSERTED = " + rows);

	        return rows > 0;

	    } catch (Exception e) {
	        System.out.println("❌ REGISTER FAILED – REAL ERROR BELOW");
	        e.printStackTrace();
	        return false;
	    }
	}

	public static List<User> getAllUsers() {

        List<User> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps =
                    con.prepareStatement("SELECT id,name,email,role FROM users");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));
                u.setEmail(rs.getString("email"));
                u.setRole(rs.getString("role"));
                list.add(u);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;   // ✅ REQUIRED
    }

    // ===============================
    // UPDATE USER
    // ===============================
    public static boolean updateUser(User user) {

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE users SET name=?, email=?, role=? WHERE id=?"
            );

            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getRole());
            ps.setInt(4, user.getId());

            ps.executeUpdate();
            return true;   // ✅ REQUIRED

        } catch (Exception e) {
            e.printStackTrace();
            return false;  // ✅ REQUIRED
        }
    }

    // ===============================
    // DELETE USER
    // ===============================
    public static boolean deleteUser(int id) {

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps =
                    con.prepareStatement("DELETE FROM users WHERE id=?");

            ps.setInt(1, id);
            ps.executeUpdate();
            return true;   // ✅ REQUIRED

        } catch (Exception e) {
            e.printStackTrace();
            return false;  // ✅ REQUIRED
        }
    }

	
	public static boolean changePassword(String email,
            String oldPass,
            String newPass) {
		try {
			Connection con = DBConnection.getConnection();

// STEP 1: Check old password 
			PreparedStatement check = con.prepareStatement(
					"SELECT * FROM users WHERE email=? AND password=?"
					);
			check.setString(1, email);
			check.setString(2, oldPass);
			ResultSet rs = check.executeQuery();
			if (!rs.next()) {
				return false; // old password wrong
				}

// STEP 2: Update new password 
			PreparedStatement update = con.prepareStatement(
					"UPDATE users SET password=? WHERE email=?"
					);
			update.setString(1, newPass);
			update.setString(2, email);
			update.executeUpdate();
			return true;
			}
		catch (Exception e) {
			e.printStackTrace();
			return false;
			}
		}
	public static User login(String email, String password) {

	    try {
	        Connection con = DBConnection.getConnection();
	        PreparedStatement ps = con.prepareStatement(
	            "SELECT * FROM users WHERE email=? AND password=?"
	        );

	        ps.setString(1, email);
	        ps.setString(2, password);

	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            User u = new User();
	            u.setId(rs.getInt("id"));
	            u.setName(rs.getString("name"));
	            u.setEmail(rs.getString("email"));
	            u.setRole(rs.getString("role"));
	            return u;   // ✅ IMPORTANT
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return null;   // ❌ login failed
	}
}
	

