package com.example.leavemanagement.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.example.leavemanagement.model.Leave;
import com.example.leavemanagement.util.DBConnection;

public class LeaveDAO {

    // APPLY LEAVE
	public static boolean applyLeave(Leave leave) {
	    try {
	        Connection con = DBConnection.getConnection();

	        PreparedStatement ps = con.prepareStatement(
	            "INSERT INTO leaves(user_email, from_date, to_date, leave_type, reason, status) VALUES (?, ?, ?, ?, ?, ?)"
	        );

	        ps.setString(1, leave.getUserEmail());
	        ps.setDate(2, java.sql.Date.valueOf(leave.getFromDate()));
	        ps.setDate(3, java.sql.Date.valueOf(leave.getToDate()));
	        ps.setString(4, leave.getLeaveType());
	        ps.setString(5, leave.getReason());
	        ps.setString(6, "PENDING");

	        ps.executeUpdate();
	        return true;

	    } catch (Exception e) {
	        System.out.println("APPLY LEAVE ERROR:");
	        e.printStackTrace();
	        return false;
	    }
	}


	
    // EMPLOYEE LEAVES
    public static List<Leave> getLeavesByEmail(String email) {
        List<Leave> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM leaves WHERE user_email=?"
            );
            ps.setString(1, email);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Leave l = new Leave();
                l.setId(rs.getInt("id"));
                l.setUserEmail(rs.getString("user_email"));
                l.setFromDate(rs.getString("from_date"));
                l.setToDate(rs.getString("to_date"));
                l.setLeaveType(rs.getString("leave_type"));
                l.setReason(rs.getString("reason"));
                l.setStatus(rs.getString("status"));
                list.add(l);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    

    // MANAGER LEAVES
    public static List<Leave> getAllLeaves() {
        List<Leave> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM leaves");

            while (rs.next()) {
                Leave l = new Leave();
                l.setId(rs.getInt("id"));
                l.setUserEmail(rs.getString("user_email"));
                l.setFromDate(rs.getString("from_date"));
                l.setToDate(rs.getString("to_date"));
                l.setLeaveType(rs.getString("leave_type"));
                l.setReason(rs.getString("reason"));
                l.setStatus(rs.getString("status"));
                list.add(l);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void updateStatus(int id, String status) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "UPDATE leaves SET status=? WHERE id=?"
            );
            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
