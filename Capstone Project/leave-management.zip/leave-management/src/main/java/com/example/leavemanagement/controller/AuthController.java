package com.example.leavemanagement.controller;

import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;

import com.example.leavemanagement.dao.UserDAO;
import com.example.leavemanagement.model.User;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {

    // ================= REGISTER =================
	@PostMapping("/register")
	public String register(@RequestParam String name,
	                        @RequestParam String email,
	                        @RequestParam String password,
	                        @RequestParam String role) {

	    System.out.println("🔥 REGISTER HIT 🔥");
	    System.out.println("Name=" + name);
	    System.out.println("Email=" + email);
	    System.out.println("Password=" + password);
	    System.out.println("Role=" + role);

	    User user = new User();
	    user.setName(name);
	    user.setEmail(email);
	    user.setPassword(password);
	    user.setRole(role);

	    return UserDAO.register(user) ? "SUCCESS" : "FAILED";
	}


    // ================= LOGIN =================
	@PostMapping("/login")
	public String login(@RequestParam String email,
	                    @RequestParam String password,
	                    HttpSession session) {

	    System.out.println("LOGIN EMAIL = " + email);
	    System.out.println("LOGIN PASSWORD = " + password);

	    User dbUser = UserDAO.login(email, password);

	    if (dbUser == null) {
	        return "<script>alert('Invalid credentials');window.location='/login.html';</script>";
	    }

	    session.setAttribute("user", dbUser);

	    if ("MANAGER".equalsIgnoreCase(dbUser.getRole())) {
	        return "<script>window.location='/manager/dashboard.html';</script>";
	    } else {
	        return "<script>window.location='/employee/dashboard.html';</script>";
	    }
	}

    // ================= LOGOUT =================
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "LOGOUT_SUCCESS";
    }
}
