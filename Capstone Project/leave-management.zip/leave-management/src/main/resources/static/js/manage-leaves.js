fetch("/leave/all")
.then(res => res.json())
.then(data => {
    let rows = "";
    data.forEach(l => {
        rows += `
        <tr>
            <td>${l.userEmail}</td>
            <td>${l.fromDate}</td>
            <td>${l.toDate}</td>
            <td>${l.leaveType}</td>
            <td>${l.reason}</td>
            <td><span class="status ${l.status}">${l.status}</span></td>
            <td>
                <button class="approve" onclick="approve(${l.id})">Approve</button>
                <button class="reject" onclick="reject(${l.id})">Reject</button>
            </td>
        </tr>`;
    });
    document.getElementById("leaveTable").innerHTML = rows;
});

function approve(id) {
    fetch("/leave/approve/" + id, { method: "PUT" })
    .then(() => location.reload());
}

function reject(id) {
    fetch("/leave/reject/" + id, { method: "PUT" })
    .then(() => location.reload());
}
