document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("loginForm");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const formData = new FormData(form);

        console.log("EMAIL SENT =", formData.get("email"));
        console.log("PASSWORD SENT =", formData.get("password"));

        fetch("/auth/login", {
            method: "POST",
            body: formData
        })
        .then(res => res.text())
        .then(msg => {
            alert("SERVER: " + msg);

			if (user.role === "EMPLOYEE") {
			                window.location.href = "/employee/apply-leave.html";
			            }  
            else if (msg === "MANAGER") {
                window.location.href = "/manager/dashboard.html";
            } 
            else {
                alert("Invalid credentials");
            }
        });
    });
});
