const users = [
    { name: "Project Manager", email: "manager@email.com", role: "MANAGER" },
    { name: "harini s", email: "harini@gmail.com", role: "EMPLOYEE" },
    { name: "Harshita Sri R", email: "harshi@gmail.com", role: "EMPLOYEE" }
];

const table = document.getElementById("userTable");

users.forEach(u => {
    table.innerHTML += `
        <tr>
            <td>${u.name}</td>
            <td>${u.email}</td>
            <td>${u.role}</td>
            <td class="action">
                <i class="fa fa-edit"></i>
                <i class="fa fa-trash"></i>
            </td>
        </tr>
    `;
});
// LOAD USERS
fetch("/users/all")
    .then(res => res.json())
    .then(data => {
        let rows = "";
        data.forEach(u => {
            rows += `
                <tr>
                    <td>${u.name}</td>
                    <td>${u.email}</td>
                    <td>${u.role}</td>
                    <td>
                        <button onclick="editUser(${u.id}, '${u.name}', '${u.email}', '${u.role}')">
                            ✏️ Edit
                        </button>
                    </td>
                </tr>
            `;
        });
        document.querySelector("#usersTable tbody").innerHTML = rows;
    });

// OPEN EDIT MODAL
function editUser(id, name, email, role) {
    document.getElementById("editId").value = id;
    document.getElementById("editName").value = name;
    document.getElementById("editEmail").value = email;
    document.getElementById("editRole").value = role;

    document.getElementById("editModal").style.display = "block";
}

// CLOSE MODAL
function closeModal() {
    document.getElementById("editModal").style.display = "none";
}

// SAVE UPDATED USER
function saveUser() {

    const user = {
        id: document.getElementById("editId").value,
        name: document.getElementById("editName").value,
        email: document.getElementById("editEmail").value,
        role: document.getElementById("editRole").value
    };

    fetch("/users/update", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(user)
    })
    .then(res => res.text())
    .then(msg => {
        if (msg === "UPDATED") {
            alert("User updated successfully");
            location.reload();
        } else {
            alert("Update failed");
        }
    });
}
