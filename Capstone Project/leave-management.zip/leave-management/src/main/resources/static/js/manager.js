document.addEventListener("DOMContentLoaded", function () {

    var calendarEl = document.getElementById("calendar");

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        height: "auto",
        headerToolbar: {
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,timeGridWeek,listWeek"
        },

        events: function (fetchInfo, successCallback) {
            fetch("/leave/all")
                .then(res => res.json())
                .then(data => {

                    let events = data.map(l => ({
                        title: l.userEmail,
                        start: l.fromDate,
                        end: l.toDate,
                        backgroundColor:
                            l.status === "ACCEPTED" ? "#2ecc71" :
                            l.status === "REJECTED" ? "#e74c3c" :
                            "#3498db"
                    }));

                    successCallback(events);
                });
        }
    });

    calendar.render();
});
