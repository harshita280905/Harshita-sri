let allLeaves = [];
let calendar;

document.addEventListener("DOMContentLoaded", function () {

    const calendarEl = document.getElementById("calendar");

    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        events: []
    });

    calendar.render();

    // Load leaves from backend
    fetch("/leave/all")
        .then(res => res.json())
        .then(data => {
            allLeaves = data;
            renderCalendar();
        });

    // Checkbox listeners
    document.getElementById("pendingChk").addEventListener("change", renderCalendar);
    document.getElementById("acceptedChk").addEventListener("change", renderCalendar);
    document.getElementById("rejectedChk").addEventListener("change", renderCalendar);
});

function renderCalendar() {

    calendar.removeAllEvents();

    const showPending = document.getElementById("pendingChk").checked;
    const showAccepted = document.getElementById("acceptedChk").checked;
    const showRejected = document.getElementById("rejectedChk").checked;

    allLeaves.forEach(l => {

        if (
            (l.status === "PENDING" && !showPending) ||
            (l.status === "ACCEPTED" && !showAccepted) ||
            (l.status === "REJECTED" && !showRejected)
        ) return;

        calendar.addEvent({
            title: l.userEmail,
            start: l.fromDate,
            end: l.toDate,
            color: getColor(l.status)
        });
    });
}

function getColor(status) {
    if (status === "PENDING") return "#2196f3";
    if (status === "ACCEPTED") return "#4caf50";
    if (status === "REJECTED") return "#f44336";
}
