document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("registerForm");

    if (!form) {
        console.log("❌ registerForm not found");
        return;
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        console.log("✅ Register button clicked");

        fetch("/auth/register", {
            method: "POST",
            body: new FormData(form)
        })
        .then(res => res.text())
        .then(msg => {
            console.log("Response:", msg);

            if (msg === "SUCCESS") {
                alert("Registration successful");
                window.location.href = "/login.html";
            } else {
                alert("Registration failed");
            }
        })
        .catch(err => console.error(err));
    });
});
