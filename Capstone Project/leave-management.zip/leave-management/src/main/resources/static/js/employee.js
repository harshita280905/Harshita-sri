document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("leaveForm");

    if (!form) return;

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const formData = new URLSearchParams(new FormData(form));

        fetch("/leave/apply", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: formData
        })
        .then(res => res.text())
        .then(data => {
            console.log("SERVER RESPONSE:", data);

            if (data === "SUCCESS") {
                alert("Leave Applied Successfully");
                window.location.href = "/employee/my-leaves.html";
            } else if (data === "NOT_LOGGED_IN") {
                alert("Please login again");
                window.location.href = "/login.html";
            } else {
                alert("Failed to apply leave");
            }
        })
        .catch(err => {
            console.error(err);
            alert("Server error");
        });
    });

});
