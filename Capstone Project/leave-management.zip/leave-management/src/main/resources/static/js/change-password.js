function changePassword() {

    const currentPassword = document.getElementById("currentPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {
        alert("New password and confirm password do not match");
        return;
    }

    fetch("/users/change-password", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            currentPassword: currentPassword,
            newPassword: newPassword
        })
    })
    .then(res => res.text())
    .then(msg => {
        if (msg === "SUCCESS") {
            alert("Password changed successfully");
            window.location.href = "/employee/dashboard.html";
        } else if (msg === "INVALID_PASSWORD") {
            alert("Current password is wrong");
        } else {
            alert("Please login again");
            window.location.href = "/login.html";
        }
    });
}
