function applyLeave() {
    fetch("/leave/apply", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body:
            "fromDate=" + fromDate.value +
            "&toDate=" + toDate.value +
            "&leaveType=" + leaveType.value +
            "&reason=" + reason.value
    })
    .then(res => res.text())
    .then(data => {
        if (data === "SUCCESS") {
            alert("Leave Applied");
            window.location.href = "/employee/my-leaves.html";
        } else {
            alert("Error");
        }
    });
}
