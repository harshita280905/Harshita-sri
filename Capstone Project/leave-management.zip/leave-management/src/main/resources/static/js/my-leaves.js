fetch("/leave/my")
.then(res => res.json())
.then(data => {

    const table = document.getElementById("leaveTable");
    table.innerHTML = "";

    data.forEach(l => {
        table.innerHTML += `
            <tr>
                <td>${l.fromDate}</td>
                <td>${l.toDate}</td>
                <td>${l.leaveType}</td>
                <td>${l.reason}</td>
                <td>
                    <span class="status ${l.status}">
                        ${l.status}
                    </span>
                </td>
            </tr>
        `;
    });
});
