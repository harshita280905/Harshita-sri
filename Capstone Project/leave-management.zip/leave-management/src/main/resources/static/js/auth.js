function login() {

    fetch("/auth/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: document.getElementById("email").value,
            password: document.getElementById("password").value
        })
    })
    .then(res => res.json())
    .then(user => {

        if (user == null) {
            alert("Invalid email or password");
            return;
        }

        // Redirect by role
        if (user.role === "MANAGER") {
            window.location.href = "/manager/dashboard.html";
        } else {
            window.location.href = "/employee/dashboard.html";
        }
    });
}
